AJITH JARVIS - Android Studio Source Project
============================================

இந்த ZIP-ல் Android Studio project source code உள்ளது. இது இன்னும் APK அல்ல.

இந்த starter version-ல்:
- AJITH JARVIS blue interface
- Tamil speech input (Android speech recognition service மூலம்)
- Text-to-speech reply (Tamil voice கிடைத்தால்; இல்லையெனில் English fallback)
- Permission-first action approval buttons
- Supported demo actions: tell time, open YouTube, Google search, open Calculator
- Microphone starts only after the user taps START LISTENING

முக்கியமான வரம்புகள்:
1. இந்த project-ஐ இங்கு APK ஆக build செய்து சோதிக்க Android SDK/Gradle build environment இல்லை.
2. “Jarvis” என்று சொன்னால் app மூடப்பட்டிருந்தாலும் அல்லது screen lock இருந்தாலும் எழுப்புவது இந்த starter build-ல் இல்லை. Android-ல் always-on wake word-க்கு foreground microphone service, explicit start/notification, battery and OS restrictions, and a dedicated wake-word engine தேவை. Screen-lock activation உறுதி செய்ய முடியாது.
3. Offline speech recognition, phone-ல் நிறுவிய speech engine/model-ஐப் பொறுத்தது; எல்லா சாதனங்களிலும் உறுதி இல்லை.
4. Power button-ஐ app தன் விருப்பப்படி மாற்ற முடியாது. Android shortcut/Quick Settings tile போன்ற supported entry point பின்னர் சேர்க்கலாம்.
5. Voice recognition result-ஐ default Android speech service process செய்கிறது; privacy policy and offline setting அந்த service-ஐப் பொறுத்தது.

Build செய்ய:
- PC-ல் Android Studio நிறுவவும்.
- இந்த folder-ஐ Android Studio-ல் Open செய்யவும்.
- Gradle sync முடிக்கவும்.
- Android SDK Platform 35 மற்றும் compatible Android Gradle Plugin downloads அனுமதிக்கவும்.
- Run > Run 'app' மூலம் உங்கள் phone-ல் install செய்யவும்.
- APK: Build > Build Bundle(s) / APK(s) > Build APK(s).

முதலில் Android Studio-வில் build செய்து phone-ல் test செய்யவும். இது starter project; production-ready assistant அல்ல.
