package com.ajith.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var transcript: TextView
    private lateinit var speakButton: Button
    private lateinit var tts: TextToSpeech
    private var pendingAction: (() -> Unit)? = null
    private var listeningForCommand = false
    private val requestMic = 41

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
    }

    private fun buildUi() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 48, 28, 28)
            setBackgroundColor(0xFF061426.toInt())
        }
        val title = TextView(this).apply {
            text = "AJITH  J.A.R.V.I.S"
            textSize = 27f
            setTextColor(0xFF55D9FF.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "PERSONAL VOICE ASSISTANT  •  BOSS MODE"
            textSize = 11f
            setTextColor(0xFF9BC7DD.toInt())
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "READY, BOSS"
            textSize = 19f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 44, 0, 24)
        }
        transcript = TextView(this).apply {
            text = "Tap the microphone and say “Jarvis” followed by a command.\n\nEvery action asks for your approval."
            textSize = 16f
            setTextColor(0xFFD7EAF5.toInt())
            gravity = Gravity.CENTER
            setPadding(8, 18, 8, 28)
        }
        speakButton = Button(this).apply {
            text = "🎙  START LISTENING"
            textSize = 17f
            setOnClickListener { beginListening() }
        }
        val stop = Button(this).apply {
            text = "STOP"
            setOnClickListener {
                pendingAction = null
                status.text = "STOPPED"
                transcript.text = "Listening stopped. No action was performed."
                say("Stopped, Boss.")
            }
        }
        val note = TextView(this).apply {
            text = "MICROPHONE IS USED ONLY AFTER YOU TAP START.\nThis starter version does not listen in the background or on the lock screen."
            textSize = 12f
            setTextColor(0xFF8BA7B9.toInt())
            gravity = Gravity.CENTER
            setPadding(8, 30, 8, 0)
        }
        page.addView(title)
        page.addView(subtitle)
        page.addView(status)
        page.addView(transcript, LinearLayout.LayoutParams(-1, 0, 1f))
        page.addView(speakButton, LinearLayout.LayoutParams(-1, -2))
        page.addView(stop, LinearLayout.LayoutParams(-1, -2))
        page.addView(note)
        setContentView(page)
    }

    private fun beginListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "VOICE SERVICE UNAVAILABLE"
            transcript.text = "Install or enable a speech recognition service on Android, then try again."
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), requestMic)
            return
        }
        listeningForCommand = false
        listenOnce()
    }

    private fun listenOnce() {
        val recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ta-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ta-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Say Jarvis and your command")
        }
        status.text = "LISTENING, BOSS…"
        recognizer.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "PROCESSING…" }
            override fun onError(error: Int) {
                status.text = "READY, BOSS"
                transcript.text = "I couldn't hear that. Tap Start Listening and try again."
                recognizer.destroy()
            }
            override fun onResults(results: Bundle?) {
                val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                recognizer.destroy()
                handleSpeech(words)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        recognizer.startListening(intent)
    }

    private fun handleSpeech(raw: String) {
        val command = raw.lowercase(Locale.ROOT).trim()
        transcript.text = "You said: $raw"
        if (command.isBlank()) {
            status.text = "READY, BOSS"
            return
        }
        // Wake phrase is checked only during a user-started listening session.
        val cleaned = command.replace("hey jarvis", "").replace("jarvis", "").trim()
        if (cleaned.isBlank()) {
            say("Yes Boss. Please say your command.")
            transcript.text = "Heard the wake word. Tap Start Listening again and say a command."
            status.text = "WAITING FOR COMMAND"
            return
        }
        val action: (() -> Unit)? = when {
            cleaned.contains("time") || cleaned.contains("நேரம்") -> {
                val now = java.text.SimpleDateFormat("hh:mm a", Locale.getDefault()).format(java.util.Date())
                { say("Boss, the time is $now") }
            }
            cleaned.contains("youtube") -> { { openUrl("https://www.youtube.com") } }
            cleaned.contains("google") || cleaned.contains("search") -> {
                val query = cleaned.replace("search", "").replace("google", "").trim()
                { openUrl("https://www.google.com/search?q=" + Uri.encode(query.ifBlank { "latest news" })) }
            }
            cleaned.contains("calculator") -> { { launchCalculator() } }
            else -> null
        }
        if (action == null) {
            status.text = "COMMAND NOT SUPPORTED"
            transcript.text = "I understood: $raw\nThis starter build supports time, YouTube, Google search and calculator."
            say("Sorry Boss. This command is not available yet.")
            return
        }
        pendingAction = action
        status.text = "PERMISSION REQUIRED"
        transcript.text = "Proposed action:\n$raw\n\nSay YES to approve or NO to cancel. For this starter build, use the buttons below."
        showApprovalButtons()
        say("Boss, may I perform this action?")
    }

    private fun showApprovalButtons() {
        val root = findViewById<LinearLayout>(android.R.id.content).getChildAt(0) as? LinearLayout ?: return
        // Remove previous approval controls.
        for (i in root.childCount - 1 downTo 0) {
            val child = root.getChildAt(i)
            if (child.tag == "approval") root.removeViewAt(i)
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; tag = "approval" }
        val yes = Button(this).apply {
            text = "YES — ALLOW"
            setOnClickListener {
                val task = pendingAction
                pendingAction = null
                removeApprovalButtons()
                status.text = "APPROVED"
                task?.invoke()
            }
        }
        val no = Button(this).apply {
            text = "NO — CANCEL"
            setOnClickListener {
                pendingAction = null
                removeApprovalButtons()
                status.text = "CANCELLED"
                transcript.text = "Cancelled. Nothing was opened."
                say("Cancelled, Boss.")
            }
        }
        row.addView(yes, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(no, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row, root.childCount - 1)
    }

    private fun removeApprovalButtons() {
        val root = findViewById<LinearLayout>(android.R.id.content).getChildAt(0) as? LinearLayout ?: return
        for (i in root.childCount - 1 downTo 0) if (root.getChildAt(i).tag == "approval") root.removeViewAt(i)
    }

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            status.text = "DONE, BOSS"
        } catch (_: Exception) {
            status.text = "COULD NOT OPEN"
        }
    }

    private fun launchCalculator() {
        try {
            startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALCULATOR))
            status.text = "DONE, BOSS"
        } catch (_: Exception) {
            say("Calculator app not found, Boss.")
        }
    }

    private fun say(message: String) {
        if (::tts.isInitialized) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            val tamil = tts.setLanguage(Locale("ta", "IN"))
            if (tamil == TextToSpeech.LANG_MISSING_DATA || tamil == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.setLanguage(Locale.US)
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestMic && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            beginListening()
        } else {
            status.text = "MICROPHONE PERMISSION DENIED"
            transcript.text = "Microphone permission is required for voice input. You can still open the app and review this screen."
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
